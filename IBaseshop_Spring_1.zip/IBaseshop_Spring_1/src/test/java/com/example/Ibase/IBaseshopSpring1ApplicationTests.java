package com.example.Ibase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IBaseshopSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
