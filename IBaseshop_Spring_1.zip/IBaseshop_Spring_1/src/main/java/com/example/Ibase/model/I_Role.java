package com.example.Ibase.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "roles")
public class I_Role {
	 @Id
	 private String id;

	 private I_ERole name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public I_ERole getName() {
		return name;
	}

	public void setName(I_ERole name) {
		this.name = name;
	}
	 
	 

}
