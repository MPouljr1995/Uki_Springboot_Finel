package com.example.Ibase.model;

public class I_Address {
	String OwnAddress;
	String Distic;
	
	
	public I_Address(String ownAddress, String distic) {
		super();
		OwnAddress = ownAddress;
		Distic = distic;
	}


	public String getOwnAddress() {
		return OwnAddress;
	}


	public void setOwnAddress(String ownAddress) {
		OwnAddress = ownAddress;
	}


	public String getDistic() {
		return Distic;
	}


	public void setDistic(String distic) {
		Distic = distic;
	}
	

}
