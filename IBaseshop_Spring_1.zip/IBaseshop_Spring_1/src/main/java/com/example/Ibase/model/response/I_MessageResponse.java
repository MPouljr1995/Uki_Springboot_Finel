package com.example.Ibase.model.response;

public class I_MessageResponse {
	private String message;

	public I_MessageResponse(String message) {
		super();
		this.message = message;
	}

	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
