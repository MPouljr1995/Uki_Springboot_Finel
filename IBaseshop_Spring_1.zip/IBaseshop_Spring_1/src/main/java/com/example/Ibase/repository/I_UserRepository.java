package com.example.Ibase.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.Ibase.model.I_User;


@Repository
public interface I_UserRepository extends MongoRepository<I_User, String>{
	Optional<I_User> findByUsername(String username);

	  Boolean existsByUsername(String username);

	  Boolean existsByEmail(String email);


}
