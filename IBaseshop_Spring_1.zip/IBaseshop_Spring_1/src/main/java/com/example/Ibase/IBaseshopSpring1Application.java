package com.example.Ibase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IBaseshopSpring1Application {

	public static void main(String[] args) {
		SpringApplication.run(IBaseshopSpring1Application.class, args);
	}

}
