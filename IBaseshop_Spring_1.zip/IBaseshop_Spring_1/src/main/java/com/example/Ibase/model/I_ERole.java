package com.example.Ibase.model;

public enum I_ERole {
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_SHOPADMIN

}
