package com.example.Ibase.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Ibase.config.I_BasicAuthUtils;
import com.example.Ibase.model.I_ERole;
import com.example.Ibase.model.I_Role;
import com.example.Ibase.model.I_User;
import com.example.Ibase.model.request.I_SigninRequest;
import com.example.Ibase.model.request.I_SignupRequest;
import com.example.Ibase.model.response.I_MessageResponse;
import com.example.Ibase.repository.I_RoleRepository;
import com.example.Ibase.repository.I_UserRepository;

@RestController
public class I_AllUser {
	
	@Autowired
	I_UserRepository userRepository;
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	I_RoleRepository roleRepository;
	
	@Autowired
	I_BasicAuthUtils basicAuthUtils;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	
	////////////////////////////////////////////////////////////////////////////
	
	@GetMapping("/all")
	public void Alluser() {
		
	}
	
	@PostMapping("/signup")
	public ResponseEntity<?> Signup_Newuser(@Valid @RequestBody I_SignupRequest signupRequest ) {
		if(userRepository.existsByUsername(signupRequest.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new I_MessageResponse(" Username is already taken!"));
		}
		
		if(userRepository.existsByEmail(signupRequest.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new I_MessageResponse(" Email is already in use!"));
		}
		
		//create new user.......
		I_User user = new I_User(signupRequest.getUsername(),
								signupRequest.getEmail(),
								encoder.encode(signupRequest.getPassword()));
		
		
		Set<String> strRoles = signupRequest.getRoles();
		Set<I_Role> roles = new HashSet<>();
		
		if (strRoles == null) {
			I_Role userRole = roleRepository.findByName(I_ERole.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			roles.add(userRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case "shopadmin":
					I_Role adminRole = roleRepository.findByName(I_ERole.ROLE_SHOPADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);
					break;
				case "mod":
					I_Role modRole = roleRepository.findByName(I_ERole.ROLE_MODERATOR)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(modRole);

					break;
				default:
					I_Role userRole = roleRepository.findByName(I_ERole.ROLE_USER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(userRole);
				}
			});
		}
		
		user.setRoles(roles);
		userRepository.save(user);

		return ResponseEntity.ok(new I_MessageResponse("User registered successfully!"));
	}
	
	@PostMapping("/signin")
//	public void Signin_user() {
//		
//	}
	
	public ResponseEntity<?> Signin_user(@Valid @RequestBody I_SigninRequest signinRequest) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(signinRequest.getUsername(), signinRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String basicToken = basicAuthUtils.generateBasicToken(signinRequest.getUsername(), signinRequest.getPassword());
		
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());

		return ResponseEntity.ok(new BasicAuthResponse(basicToken, 
												 userDetails.getId(), 
												 userDetails.getUsername(), 
												 userDetails.getEmail(), 
												 roles));
	}
	

}
