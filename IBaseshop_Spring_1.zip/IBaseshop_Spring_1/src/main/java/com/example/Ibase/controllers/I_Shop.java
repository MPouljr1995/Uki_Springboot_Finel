package com.example.Ibase.controllers;


import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class I_Shop {
	
	@GetMapping("/shops")
	public void view_shops() {
		
	}
	
	@PostMapping("/addshop")
	@PreAuthorize("hasRole('ROLE_USER')")
	public void Addnew_shop() {
		
	}
	
	@PostMapping("/additem")
	@PreAuthorize("hasRole('ROLE_SHOPADMIN')")
	public void Addnew_item() {
		
	}
	

}
