package com.example.Ibase.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.Ibase.model.I_ERole;
import com.example.Ibase.model.I_Role;

@Repository
public interface I_RoleRepository extends MongoRepository<I_Role, String> {
	Optional<I_Role> findByName(I_ERole name);

}
